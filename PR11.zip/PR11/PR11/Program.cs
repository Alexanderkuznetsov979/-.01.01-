﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR11
{
    class Program
    {
        static void Main(string[] args)
        {
            //Вариант № 10
            //1. Ввести пять различных ненулевых целых чисел. Найти два наибольших числа.
            Console.WriteLine("1. Ввести пять различных ненулевых целых чисел. Найти два наибольших числа");
        
            int a1 = 0, a2 = 0, a3 = 0, a4 = 0, a5 = 0;
            int max1 = 0, max2 = 0;
            int nom =0;
            while(nom==0)
            { 
                try
                {
                  Console.WriteLine("Введите 1 число");
                  a1 = Convert.ToInt32(Console.ReadLine());
                  Console.WriteLine("Введите 2 число");
                  a2 = Convert.ToInt32(Console.ReadLine());
                  Console.WriteLine("Введите 3 число");
                  a3 = Convert.ToInt32(Console.ReadLine());
                  Console.WriteLine("Введите 4 число");
                  a4 = Convert.ToInt32(Console.ReadLine());
                  Console.WriteLine("Введите 5 число");
                  a5 = Convert.ToInt32(Console.ReadLine());
                  nom++;
                }
                catch
                {
                    Console.WriteLine("\nОшибка, повторите попытку! ");
                }
                if (a1 < 0)
                {
                    nom = 0;
                }
                if (a2 < 0)
                {
                    nom = 0;
                }
                if (a3 < 0)
                {
                    nom = 0;
                }
                if (a4 < 0)
                {
                    nom = 0;
                }
                if (a5 < 0)
                {
                    nom = 0;
                }
            }
           
       
            if(a1 !=0 && a2!=0 && a3!=0 &&a4!=0&& a5!=0)
            {
            if (max1 < a1)
            {
                max1 = a1;
            }
            if (max1 < a2)
            {
                max1 = a2;
            }
            if (max1 < a3)
            {
                max1 = a3;
            }
            if (max1 < a4)
            {
                max1 = a4;
            }
            if (max1 < a5)
            {
                max1 = a5;
            }

            if (max1 != a1 && max2 < a1)
            {
                max2 = a1;
            }
            if (max1 != a2 && max2 < a2)
            {
                max2 = a2;
            }
            if (max1 != a3 && max2 < a3)
            {
                max2 = a3;
            }
            if (max1 != a4 && max2 < a4)
            {
                max2 = a4;
            }
            if (max1 != a5 && max2 < a5)
            {
                max2 = a5;
            }
            
            }
            Console.WriteLine("Первое число:{0}\n ", max1);
            Console.WriteLine("Второе число:{0}\n ", max2);
            
            //2. Проверить истинность высказывания: "Цифры данного целого положительного трехзначного числа, 
            //введенного с клавиатуры, образуют убывающую последовательность".
            int nom1 = 0;
            int gef=0;
            Console.WriteLine("2. Проверить истинность высказывания: Цифры данного целого положительного трехзначного числа,\nвведенного с клавиатуры, образуют убывающую последовательность.\n");
  m100:
            while (nom1 == 0)
            {
               try
               { 
                   Console.WriteLine("Введите число");
                   gef = Convert.ToInt32(Console.ReadLine()); 
                   nom1++;
               }
               catch
               {
                   Console.WriteLine("\nОшибка, повторите попытку! ");
               }
               if (gef < 0)
               {
                   nom1 = 0;
               }
            }
            
                
                if(gef>99 && gef<1000 && gef>0)
            {
                if(((gef/100)>(gef%100/10)) & ((gef%100/10)>(gef%10)))
                {
                    Console.WriteLine("Убывающая последовательность образуется");
                }
                else 
                {
                    Console.WriteLine("Убывающая последовательность не образуется");
                }  
            }
            else
            {
                Console.WriteLine("Введите корректное значение");
                goto m100;
            }
        }    
    }
  }